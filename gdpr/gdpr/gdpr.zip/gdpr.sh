#!/bin/bash
java -jar gdpr.jar $*